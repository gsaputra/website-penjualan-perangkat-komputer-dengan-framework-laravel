$(document).ready(function() {

  $('#kategori').dataTable( {
      "iDisplayLength": 5,
      "bLengthChange": false,
      "columns": [
          null,
          null,
          { "width": "15%" }
        ]
      }
    );

  $('#pembeli').dataTable( {
      "iDisplayLength": 5,
      "bLengthChange": false,
      "columns": [
          null,
          null,
          null,
          null,
          null,
          null,
          { "width": "15%" }
        ]
      }
    );

    $('#barang').dataTable( {
        "iDisplayLength": 5,
        "bLengthChange": false,
        "columns": [
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            { "width": "15%" }
          ]
        }
      );

      $('#konfirmasi').dataTable( {
          "iDisplayLength": 5,
          "bLengthChange": false,
          "columns": [
              { "width": "5%" },
              null,
              null,
              null,
              null,
              null,
              null,
              { "width": "15%" }
            ]
          }
        );
});
