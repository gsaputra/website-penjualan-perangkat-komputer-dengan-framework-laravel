<?php include_once '../layouts/header.php';?>
<h1 class="page-header">Create Kategori</h1>
<form class="form-horizontal" action="create_proses.php" method="post">
      <div class="form-group">
          <label for="nama_kategori" class="col-sm-2 col-xs-3 control-label">Nama Kategori</label>
          <div class="col-xs-8 col-md-4">
              <input type="text" name="nama_kategori" class="form-control" id="nama_kategori" placeholder="Nama Kategori">
          </div>
      </div>
      <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Create</button>
          </div>
      </div>
  </form>
<?php include_once '../layouts/footer.php'; ?>
