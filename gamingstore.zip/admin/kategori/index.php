<?php include_once '../layouts/header.php';?>
  <h1 class="page-header">Kategori</h1>
  <a class="btn btn-primary" href="create.php" role="button" >CREATE</a>
  <br>
  <br>
  <table id="kategori" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Kategori</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php
            $query = "SELECT * FROM kategori";
            $kategoris = mysqli_query($conn, $query);

            while ($kategori = mysqli_fetch_assoc($kategoris)) {
          ?>
            <tr>
              <td><?= $kategori['id_kategori']; ?></td>
              <td><?= $kategori['nama_kategori']; ?></td>
              <td>
                <center>
                  <a href="update.php?id=<?= $kategori['id_kategori']; ?>" class="btn btn-success">Edit</a>
                  <a href="delete.php?id=<?= $kategori['id_kategori']; ?>" class="btn btn-danger">Delete</a>
                </center>
              </td>
            </tr>
          <?php   } ?>
        </tbody>
    </table>
<?php
mysqli_close($conn);
include_once '../layouts/footer.php'; ?>
