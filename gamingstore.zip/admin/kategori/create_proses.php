<?php
  include_once '../../config/koneksi.php';
  $nama_kategori = $_POST['nama_kategori'];

  $query = "INSERT INTO kategori (nama_kategori) VALUES ('".$nama_kategori."')";

  $result = mysqli_query($conn, $query);

  if($result){
    header('Location: index.php');
    mysqli_close($conn);
  }else{
    header('Location: create.php');
  }
?>
