<?php
  include_once '../../config/koneksi.php';
  $id_kategori = $_POST['id_kategori'];
  $nama_kategori = $_POST['nama_kategori'];

  $query = "UPDATE kategori SET nama_kategori = '" . $nama_kategori . "' WHERE id_kategori = " . $id_kategori;

  $result = mysqli_query($conn, $query);

  if($result){
    header('Location: index.php');
    mysqli_close($conn);
  }else{
    header('Location: update.php?id='.$id_kategori);
  }
?>
