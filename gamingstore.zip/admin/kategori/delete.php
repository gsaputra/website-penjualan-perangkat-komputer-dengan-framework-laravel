<?php
  include_once '../../config/koneksi.php';
  $id_kategori = $_GET['id'];

  $query = "DELETE FROM kategori WHERE id_kategori = " . $id_kategori;

  $result = mysqli_query($conn, $query);

  if ($result) {
    header('Location: index.php');
    mysqli_close($conn);
  }
?>
