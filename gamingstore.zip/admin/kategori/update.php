<?php include_once '../layouts/header.php';

  $id_kategori = $_GET['id'];

  $query = "SELECT * FROM kategori WHERE id_kategori = " . $id_kategori;

  $result = mysqli_query($conn, $query);
?>

<h1 class="page-header">Update Kategori</h1>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<form class="form-horizontal" action="update_proses.php" method="post">
      <div class="form-group">
          <label for="nama_kategori" class="col-sm-2 col-xs-3 control-label">Nama Kategori</label>
          <div class="col-xs-8 col-md-4">
              <input type="hidden" name="id_kategori" value="<?= $row['id_kategori']; ?>" readonly>
              <input type="text" name="nama_kategori" class="form-control" id="nama_kategori" value="<?= $row['nama_kategori']; ?>" placeholder="Nama Kategori">
          </div>
      </div>
      <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
      </div>
  </form>
<?php
    }
mysqli_close($conn);
include_once '../layouts/footer.php'; ?>
