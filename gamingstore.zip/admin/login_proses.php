<?php
  session_start();
  include_once '../config/koneksi.php';
  $username = $_POST['username'];
  $password = md5($_POST['password']);

  $login = mysqli_query($conn, "SELECT * FROM admin WHERE username = '" . $username . "' AND password = '" . $password . "'");
  $result = mysqli_num_rows($login);

  if($result > 0){
    $admin = mysqli_fetch_array($login);
    $_SESSION['admin'] = 'admin';
    $_SESSION['id_admin'] = $admin['id_admin'];
    $_SESSION['nama_admin'] = $admin['nama'];
    header('Location: index.php');
   } else {
    header('Location: login.php');
  }
?>
