<?php include_once '../layouts/header.php';
$id_barang = $_GET['id'];

$query = "SELECT * FROM barang WHERE id_barang = " . $id_barang;

$result = mysqli_query($conn, $query);
?>
<h1 class="page-header">Update Barang</h1>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<form class="form-horizontal" action="update_proses.php" method="post">
      <div class="form-group">
          <label for="nama_barang" class="col-sm-2 col-xs-3 control-label">Nama Barang</label>
          <div class="col-xs-8 col-md-4">
              <input type="hidden" name="id_barang" value="<?= $id_barang; ?>" readonly>
              <input type="text" name="nama_barang" class="form-control" id="nama_barang" value="<?= $row['nama_barang']; ?>" placeholder="Nama Barang">
          </div>
      </div>
      <div class="form-group">
          <label for="harga" class="col-sm-2 col-xs-3 control-label">Harga</label>
          <div class="col-xs-8 col-md-4">
              <input type="number" name="harga" class="form-control" id="harga" value="<?= $row['harga']; ?>"placeholder="Harga">
          </div>
      </div>
      <div class="form-group">
          <label for="stok" class="col-sm-2 col-xs-3 control-label">Stok</label>
          <div class="col-xs-8 col-md-4">
              <input type="number" name="stok" class="form-control" id="stok" value="<?= $row['stok']; ?>" placeholder="Stok">
          </div>
      </div>
      <div class="form-group">
          <label for="username" class="col-sm-2 col-xs-3 control-label">Kategori</label>
          <div class="col-xs-8 col-md-4">
            <?php
            $querykategori = "SELECT * FROM kategori";
            $kategori = mysqli_query($conn, $querykategori);
            ?>
            <select class="form-control" name="id_kategori">
              <?php
                while ($data = mysqli_fetch_assoc($kategori)) {
              ?>
                <option value="<?= $data['id_kategori']; ?>" <?= $data['id_kategori'] == $row['id_kategori'] ? 'selected' : ''; ?>><?= $data['nama_kategori']; ?></option>
              <?php }  ?>
            </select>
          </div>
      </div>
      <div class="form-group">
          <label for="password" class="col-sm-2 col-xs-3 control-label">Deskripsi</label>
          <div class="col-xs-8 col-md-8">
              <textarea class="form-control deksripsi" rows="3" name="deskripsi" id="deskripsi"><?= $row['deskripsi']; ?></textarea>
          </div>
      </div>
      <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
      </div>
  </form>
<?php
}
mysqli_close($conn);
include_once '../layouts/footer.php'; ?>
