<?php include_once '../layouts/header.php';?>
<h1 class="page-header">Create Barang</h1>
<form class="form-horizontal" action="create_proses.php" method="POST" enctype="multipart/form-data">
      <div class="form-group">
          <label for="nama_barang" class="col-sm-2 col-xs-3 control-label">Nama Barang</label>
          <div class="col-xs-8 col-md-4">
              <input type="text" name="nama_barang" class="form-control" id="nama_barang" placeholder="Nama Barang">
          </div>
      </div>
      <div class="form-group">
          <label for="harga" class="col-sm-2 col-xs-3 control-label">Harga</label>
          <div class="col-xs-8 col-md-4">
              <input type="number" name="harga" class="form-control" id="harga" placeholder="Harga">
          </div>
      </div>
      <div class="form-group">
          <label for="stok" class="col-sm-2 col-xs-3 control-label">Stok</label>
          <div class="col-xs-8 col-md-4">
              <input type="number" name="stok" class="form-control" id="stok" placeholder="Stok">
          </div>
      </div>
      <div class="form-group">
          <label for="username" class="col-sm-2 col-xs-3 control-label">Kategori</label>
          <div class="col-xs-8 col-md-4">
            <?php
            $querykategori = "SELECT * FROM kategori";
            $kategori = mysqli_query($conn, $querykategori);
            ?>
            <select class="form-control" name="id_kategori">
              <?php
                while ($row = mysqli_fetch_assoc($kategori)) {
              ?>
                <option value="<?= $row['id_kategori']; ?>"><?= $row['nama_kategori']; ?></option>
              <?php }  ?>
            </select>
          </div>
      </div>
      <div class="form-group">
          <label for="password" class="col-sm-2 col-xs-3 control-label">Deskripsi</label>
          <div class="col-xs-8 col-md-8">
              <textarea class="form-control" rows="3" name="deskripsi" id="deskripsi"></textarea>
          </div>
      </div>
      <div class="form-group">
          <label for="gambar" class="col-sm-2 col-xs-3 control-label">Gambar</label>
          <div class="col-xs-8 col-md-4">
              <input type="file" id="gambar" name="file">
          </div>
      </div>
      <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Create</button>
          </div>
      </div>
  </form>
<?php include_once '../layouts/footer.php'; ?>
