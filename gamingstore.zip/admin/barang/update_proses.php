<?php
include_once '../../config/koneksi.php';
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$deskripsi = $_POST['deskripsi'];
$stok = $_POST['stok'];
$harga = $_POST['harga'];
$id_kategori = $_POST['id_kategori'];

$query = "UPDATE barang SET nama_barang = '" . $nama_barang . "', deskripsi = '" . $deskripsi . "', stok = ".$stok.", harga = ".$harga.", id_kategori = ".$id_kategori." WHERE id_barang = " . $id_barang;

$result = mysqli_query($conn, $query);

if($result){
  header('Location: index.php');
  mysqli_close($conn);
}else{
  header('Location: update.php?id='.$id_kategori);
}
?>
