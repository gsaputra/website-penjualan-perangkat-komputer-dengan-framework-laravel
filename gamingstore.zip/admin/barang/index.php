<?php include_once '../layouts/header.php';?>
  <h1 class="page-header">Barang</h1>
  <a class="btn btn-primary" href="create.php" role="button" >CREATE</a>
  <br>
  <br>
  <table id="barang" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Barang</th>
                <th>Deskripsi</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Gambar</th>
                <th>Kategori</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
          <?php
            $query = "SELECT * FROM barang";
            $barangs = mysqli_query($conn, $query);

            while ($barang = mysqli_fetch_assoc($barangs)) {
          ?>
            <tr>
              <td><?= $barang['id_barang']; ?></td>
              <td><?= $barang['nama_barang']; ?></td>
              <td><?= substr($barang['deskripsi'], 100, 100); ?></td>
              <td><?= $barang['stok']; ?></td>
              <td><?= $barang['harga']; ?></td>
              <td><?= $barang['gambar']; ?></td>
              <td>
                <?php
                  $querykategori = "SELECT * FROM kategori WHERE id_kategori = " . $barang['id_kategori'];
                  $kategori = mysqli_query($conn, $querykategori);

                  while ($row = mysqli_fetch_assoc($kategori)) {
                    echo $row['nama_kategori'];
                  }
                ?>
              </td>
              <td>
                <center>
                  <a href="update.php?id=<?= $barang['id_barang']; ?>" class="btn btn-success">Edit</a>
                  <a href="delete.php?id=<?= $barang['id_barang']; ?>" class="btn btn-danger">Delete</a>
                </center>
              </td>
            </tr>
          <?php   } ?>
        </tbody>
    </table>
<?php
mysqli_close($conn);
include_once '../layouts/footer.php'; ?>
