<?php
include_once '../../config/koneksi.php';
$nama_barang = $_POST['nama_barang'];
$deskripsi = $_POST['deskripsi'];
$stok = $_POST['stok'];
$harga = $_POST['harga'];
$id_kategori = $_POST['id_kategori'];

$ekstensi_diperbolehkan = array('png', 'jpg');
$nama = date('d-m-Y') . $_FILES['file']['name'];
$x = explode('.', $nama);
$ekstensi = strtolower(end($x));
$ukuran = $_FILES['file']['size'];
$file_temp = $_FILES['file']['tmp_name'];

if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
  if($ukuran < 1044070 && $ukuran != 0) {
    if(move_uploaded_file($file_temp, '../../storage/'.$nama)){
      $query = "INSERT INTO barang (nama_barang, deskripsi, stok, harga, gambar, id_kategori) VALUES ('".$nama_barang."', '".$deskripsi."', ".$stok.", ".$harga.", '".$nama."', ". $id_kategori .")";

      $result = mysqli_query($conn, $query);

      if($result){
        header('Location: index.php');
        mysqli_close($conn);
      }else{
        header('Location: create.php');
      }
    } else {
      echo $ukuran;
    }
  }else{
    die('error size');
  }
}else{
  die('error ekstensi');
}

?>
