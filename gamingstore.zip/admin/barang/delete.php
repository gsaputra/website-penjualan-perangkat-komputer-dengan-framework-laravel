<?php
  include_once '../../config/koneksi.php';
  $id_barang = $_GET['id'];

  $query = "DELETE FROM barang WHERE id_barang = " . $id_barang;

  $result = mysqli_query($conn, $query);

  if ($result) {
    header('Location: index.php');
    mysqli_close($conn);
  }
?>
