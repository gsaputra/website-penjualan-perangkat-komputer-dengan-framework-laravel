<?php include_once '../layouts/header.php';
$id_pembeli = $_GET['id'];

$query = "SELECT * FROM pembeli WHERE id_pembeli = " . $id_pembeli;

$result = mysqli_query($conn, $query);
?>
<h1 class="page-header">Update Pembeli</h1>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<form class="form-horizontal" action="update_proses.php" method="post">
      <div class="form-group">
          <label for="nama" class="col-sm-2 col-xs-3 control-label">Nama</label>
          <div class="col-xs-8 col-md-4">
              <input type="hidden" name="id_pembeli" value="<?= $row['id_pembeli']; ?>" readonly>
              <input type="text" name="nama" class="form-control" id="nama" value="<?= $row['nama']; ?>" placeholder="Nama">
          </div>
      </div>
      <div class="form-group">
          <label for="telp" class="col-sm-2 col-xs-3 control-label">Telepon</label>
          <div class="col-xs-8 col-md-4">
              <input type="text" name="telp" class="form-control" id="telp" value="<?= $row['telp']; ?>" placeholder="Telepon">
          </div>
      </div>
      <div class="form-group">
          <label for="alamat" class="col-sm-2 col-xs-3 control-label">Alamat</label>
          <div class="col-xs-8 col-md-4">
              <textarea class="form-control" rows="3" name="alamat" id="alamat"><?= $row['alamat']; ?></textarea>
          </div>
      </div>
      <div class="form-group">
          <label for="username" class="col-sm-2 col-xs-3 control-label">Username</label>
          <div class="col-xs-8 col-md-4">
              <input type="text" name="username" class="form-control" id="username" value="<?= $row['username']; ?>" placeholder="Username">
          </div>
      </div>
      <div class="form-group">
          <label for="password" class="col-sm-2 col-xs-3 control-label">Password</label>
          <div class="col-xs-8 col-md-4">
              <input type="password" name="password" class="form-control" id="password" value="<?= $row['password']; ?>" placeholder="Password">
          </div>
      </div>
      <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
      </div>
  </form>
<?php
      }
mysqli_close($conn);
include_once '../layouts/footer.php'; ?>
