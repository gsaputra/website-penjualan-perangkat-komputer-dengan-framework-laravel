<?php include_once '../layouts/header.php';?>
<h1 class="page-header">Create Pembeli</h1>
<form class="form-horizontal" action="create_proses.php" method="post">
      <div class="form-group">
          <label for="nama" class="col-sm-2 col-xs-3 control-label">Nama</label>
          <div class="col-xs-8 col-md-4">
              <input type="text" name="nama" class="form-control" id="nama" placeholder="Nama">
          </div>
      </div>
      <div class="form-group">
          <label for="telp" class="col-sm-2 col-xs-3 control-label">Telepon</label>
          <div class="col-xs-8 col-md-4">
              <input type="text" name="telp" class="form-control" id="telp" placeholder="Telepon">
          </div>
      </div>
      <div class="form-group">
          <label for="alamat" class="col-sm-2 col-xs-3 control-label">Alamat</label>
          <div class="col-xs-8 col-md-4">
              <textarea class="form-control" rows="3" name="alamat" id="alamat"></textarea>
          </div>
      </div>
      <div class="form-group">
          <label for="username" class="col-sm-2 col-xs-3 control-label">Username</label>
          <div class="col-xs-8 col-md-4">
              <input type="text" name="username" class="form-control" id="username" placeholder="Username">
          </div>
      </div>
      <div class="form-group">
          <label for="password" class="col-sm-2 col-xs-3 control-label">Password</label>
          <div class="col-xs-8 col-md-4">
              <input type="password" name="password" class="form-control" id="password" placeholder="Password">
          </div>
      </div>
      <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Create</button>
          </div>
      </div>
  </form>
<?php include_once '../layouts/footer.php'; ?>
