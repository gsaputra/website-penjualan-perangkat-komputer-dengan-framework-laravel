<?php
  include_once '../../config/koneksi.php';
  
  $id_pembeli = $_POST['id_pembeli'];
  $nama = $_POST['nama'];
  $telp = $_POST['telp'];
  $alamat = $_POST['alamat'];
  $username = $_POST['username'];
  $password = md5($_POST['password']);

  $query = "UPDATE pembeli SET nama = '" . $nama . "', telp = '" . $telp . "', alamat = '" . $alamat . "', username = '" . $username . "', password = '" . $password . "'  WHERE id_pembeli = " . $id_pembeli;

  $result = mysqli_query($conn, $query);

  if($result){
    header('Location: index.php');
    mysqli_close($conn);
  }else{
    header('Location: update.php?id='.$id_kategori);
  }
?>
