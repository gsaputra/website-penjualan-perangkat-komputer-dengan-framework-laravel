<?php include_once '../layouts/header.php';?>
  <h1 class="page-header">Pembeli</h1>
  <a class="btn btn-primary" href="create.php" role="button" >CREATE</a>
  <br>
  <br>
  <table id="pembeli" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Telepon</th>
                <th>Alamat</th>
                <th>Username</th>
                <th>Password</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
          <?php
            $query = "SELECT * FROM pembeli";
            $pembelis = mysqli_query($conn, $query);

            while ($pembeli = mysqli_fetch_assoc($pembelis)) {
          ?>
            <tr>
              <td><?= $pembeli['id_pembeli']; ?></td>
              <td><?= $pembeli['nama']; ?></td>
              <td><?= $pembeli['telp']; ?></td>
              <td><?= $pembeli['alamat']; ?></td>
              <td><?= $pembeli['username']; ?></td>
              <td><?= substr($pembeli['password'], 0, 20); ?></td>
              <td>
                <center>
                  <a href="update.php?id=<?= $pembeli['id_pembeli']; ?>" class="btn btn-success">Edit</a>
                  <a href="delete.php?id=<?= $pembeli['id_pembeli']; ?>" class="btn btn-danger">Delete</a>
                </center>
              </td>
            </tr>
          <?php   } ?>
        </tbody>
    </table>
<?php
mysqli_close($conn);
include_once '../layouts/footer.php'; ?>
