<?php
  include_once '../../config/koneksi.php';
  $id_pembeli = $_GET['id'];

  $query = "DELETE FROM pembeli WHERE id_pembeli = " . $id_pembeli;

  $result = mysqli_query($conn, $query);

  if ($result) {
    header('Location: index.php');
    mysqli_close($conn);
  }
?>
