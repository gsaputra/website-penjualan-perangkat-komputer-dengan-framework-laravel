</div>
</div>
</div>

<?php $actual_link = "$_SERVER[REQUEST_URI]";
  if ($actual_link == "/gamingstore/admin/") { ?>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/dist/trumbowyg.min.js"></script>
    <script src="assets/js/app.js"></script>
<?php } else { ?>
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/jquery.dataTables.min.js"></script>
  <script src="../assets/js/dataTables.bootstrap.min.js"></script>
  <script src="../assets/dist/trumbowyg.min.js"></script>
  <script src="../assets/js/app.js"></script>
<?php } ?>
  <script>$('#deskripsi').trumbowyg();</script>

</body>
</html>
