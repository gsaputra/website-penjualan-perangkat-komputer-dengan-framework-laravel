<?php
  include_once '../../config/koneksi.php';

  $id_transaksi = $_GET['id'];

  $query = "UPDATE transaksi SET status = 'Pembayaran Diterima' WHERE id_transaksi = " . $id_transaksi;

  $result = mysqli_query($conn, $query);

  if($result){
    header('Location: index.php');
    mysqli_close($conn);
  }else{
    header('Location: index.php');
  }
 ?>
