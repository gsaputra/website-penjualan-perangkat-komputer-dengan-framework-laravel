<?php include_once '../layouts/header.php'; ?>

    <h1 class="page-header">Konfirmasi Transaksi</h1>
    <table id="konfirmasi" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>ID Transaksi</th>
          <th>Nama Pembeli</th>
          <th>Tanggal</th>
          <th>Barang</th>
          <th>Jumlah</th>
          <th>Grand Total</th>
          <th>status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $query = "SELECT * FROM transaksi ORDER BY tgl_transaksi DESC";
          $transaksis = mysqli_query($conn, $query);

          while ($transaksi = mysqli_fetch_assoc($transaksis)) {
        ?>
          <tr>
            <td><?= $transaksi['id_transaksi']; ?></td>
            <?php
              $query2 = "SELECT * FROM pembeli WHERE id_pembeli = " . $transaksi['id_pembeli'];
              $pembelis = mysqli_query($conn, $query2);
              while ($pembeli = mysqli_fetch_assoc($pembelis)) {
            ?>
              <td><?= $pembeli['nama']; ?></td>
            <?php } ?>
            <td><?= $transaksi['tgl_transaksi']; ?></td>
            <?php
              $query3 = "SELECT * FROM barang WHERE id_barang = " . $transaksi['id_barang'];
              $barangs = mysqli_query($conn, $query3);
              while ($barang = mysqli_fetch_assoc($barangs)) {
            ?>
              <td><?= $barang['nama_barang']; ?></td>
            <?php } ?>
            <td><?= $transaksi['jumlah']; ?></td>
            <td><?= $transaksi['grand_total']; ?></td>
            <td>
              <?php if ($transaksi['status'] == 'Belum Dibayar'): ?>
                <a href="#" class="btn btn-danger"><?= $transaksi['status'] ?></a>
              <?php else: ?>
                <a href="#" class="btn btn-success"><?= $transaksi['status'] ?></a>
              <?php endif; ?>
            </td>
            <td>
              <center>
                <a href="konfirmasi.php?id=<?= $transaksi['id_transaksi']; ?>" class="btn btn-primary">Konfirmasi</a>
              </center>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
<?php include_once '../layouts/footer.php'; ?>
