<?php include_once 'layouts/header.php';?>
  <h1 class="page-header">Dashboard</h1>
<?php include_once 'layouts/footer.php';?>
