<?php include_once 'layouts/header.php'; ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <table id="transaksi" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Barang</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
              <?php
                $query = "SELECT * FROM transaksi WHERE id_pembeli = " . $_SESSION['id_pembeli'];

                $transaksis = mysqli_query($conn, $query);

                while ($transaksi = mysqli_fetch_assoc($transaksis)) {
                  $queryBarang = "SELECT * FROM barang WHERE id_barang = " . $transaksi['id_barang'];
                  $barangs = mysqli_query($conn, $queryBarang);
              ?>
                <tr>
                  <td><?= $transaksi['id_transaksi']; ?></td>
                  <?php while ($barang = mysqli_fetch_assoc($barangs)) { ?>
                  <td><?= $barang['nama_barang']; ?></td>
                  <td><?= $barang['harga'] ?></td>
                  <?php }?>
                  <td><?= $transaksi['jumlah']; ?></td>
                  <td><?= $transaksi['grand_total']; ?></td>
                  <td>
                    <center>
                      <?php if ($transaksi['status'] == 'Belum Dibayar'): ?>
                        <a href="#" class="btn btn-danger"><?= $transaksi['status'] ?></a>
                      <?php else: ?>
                        <a href="#" class="btn btn-success"><?= $transaksi['status'] ?></a>
                      <?php endif; ?>
                    </center>
                  </td>
                </tr>
              <?php   } ?>
            </tbody>
        </table>
    </div>
  </div>
</div>
<?php include_once 'layouts/footer.php'; ?>
