<footer class="footer">
  <div class="container">
    <p class="text-muted">Gaming Store &copy; 2017 .</p>
  </div>
</footer>


<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="bs-example-modal-sm">
 <div class="modal-dialog modal-sm" role="document">
   <div class="modal-content">
     <div class="modal-header">
       <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
       <h4 class="modal-title" id="titlelogin">Login</h4>
     </div>
     <div class="modal-body">
       <form class="form" action="login_proses.php" method="post" role="form" id="formpembeli">
         <div class="row">
           <div class="col-md-12">
             <div id="username" class="form-group">
               <label class="control-label">Username <span class="required">*</span></label>
               <input type="text"  name="username" data-required="1" class="form-control"/>
             </div>

             <div id="password" class="form-group">
               <label class="control-label">Password <span class="required">*</span></label>
               <input type="password"  name="password" data-required="1" class="form-control"/>
             </div>

             <div class="form-group">
               <input type="submit" name="submit" class="btn btn-primary btnlogin" value="Login">
             </div>

           </div>
         </div>
       </form>
     <div class="modal-footer">
       <a href="register.php" class="btn btn-default">Register</a>
     </div>
   </div>
 </div>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
