<?php
session_start();
include_once 'config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Gaming Store</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <style media="screen">
      body {
        min-height: 2000px;
        padding-top: 70px;
        margin-bottom: 60px;
        background-color: #f5f5f5; /*ganti warna
      }
      /* Sticky footer styles -------------------------------------------------- */
      html {
        position: relative;
        min-height: 100%;
      }

      .footer {
        position: absolute;
        bottom: 0;
        width: 100%;
        /* Set the fixed height of the footer here */
        height: 60px;
        background-color: #f5f5f5;
      }

      /* Custom page CSS -------------------------------------------------- */
      /* Not required for template or sticky footer method. */

      .footer .container {
        width: auto;
        max-width: 680px;
        padding: 0 15px;
      }
      .container .text-muted {
        margin: 20px 0;
      }
      .contact-wa {
        padding : 15px;
      }
    </style>
  </head>
<!-- NAVBAR
================================================== -->
  <body>
    <!-- Fixed navbar -->
   <nav class="navbar navbar-default navbar-fixed-top">
     <div class="container">
       <div class="navbar-header">
         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
           <span class="sr-only">Toggle navigation</span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
         </button>
         <a class="navbar-brand" href="index.php">Gaming Store</a>
       </div>
       <div id="navbar" class="navbar-collapse collapse">
         <ul class="nav navbar-nav">
           <li class="active"><a href="index.php">Beranda</a></li>
           <li><a href="barang.php">Barang</a></li>
           <li class="dropdown">
             <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Kategori <span class="caret"></span></a>
             <ul class="dropdown-menu">
               <?php
                 $query = "SELECT * FROM kategori";
                 $kategoris = mysqli_query($conn, $query);

                 while ($kategori = mysqli_fetch_assoc($kategoris)) {
               ?>
               <li><a href="<?= $kategori['slug']; ?>.php"><?= $kategori['nama_kategori']; ?></a></li>
              <?php } ?>
             </ul>
           </li>
           <li><a href="tentang.php">Tentang</a></li>

         </ul>
         <ul class="nav navbar-nav navbar-right">
           <?php if (!isset($_SESSION['id_pembeli'])) { ?>
             <li><a data-toggle="modal" href="#bs-example-modal-sm" data-target="#bs-example-modal-sm">Login / Register</a></li>
           <?php } else { ?>
             <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?= $_SESSION['nama_pembeli']; ?> <span class="caret"></span></a>
               <ul class="dropdown-menu">
                 <li><a href="transaksi.php">Histori Transaksi</a></li>
                 <li><a href="logout.php">Logout</a></li>
               </ul>
             </li>
        <?php } ?>

         </ul>
       </div><!--/.nav-collapse -->
     </div>
   </nav>
