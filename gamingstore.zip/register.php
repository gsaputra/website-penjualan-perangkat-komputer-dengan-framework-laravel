<?php include_once 'layouts/header.php'; ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h1>Register Akun</h1>
    </div>
  </div>
  <div class="row">
    <div class="col-md-8 col-sm-12">
      <form class="form-horizontal" action="register_proses.php" role="form" method="post">
        <div class="form-group">
          <label for="nama" class="col-lg-4 control-label">Nama <span class="require">*</span></label>
          <div class="col-lg-8">
            <input type="text" name="nama" class="form-control" id="nama">
          </div>
        </div>
        <div class="form-group">
          <label for="telp" class="col-lg-4 control-label">Telepon <span class="require">*</span></label>
          <div class="col-lg-8">
            <input type="text" name="telp" class="form-control" id="telp">
          </div>
        </div>
        <div class="form-group">
          <label for="alamat" class="col-lg-4 control-label">Alamat <span class="require">*</span></label>
          <div class="col-lg-8">
            <textarea name="alamat" class="form-control" rows="8" cols="80"></textarea>
          </div>
        </div>
        <div class="form-group">
          <label for="nama" class="col-lg-4 control-label">Username <span class="require">*</span></label>
          <div class="col-lg-8">
            <input type="text" name="username" class="form-control" id="username">
          </div>
        </div>
        <div class="form-group">
          <label for="nama" class="col-lg-4 control-label">Password <span class="require">*</span></label>
          <div class="col-lg-8">
            <input type="password" name="password" class="form-control" id="password">
          </div>
        </div>
        <div class="row" style="margin-top: 20px">
          <div class="col-lg-12 col-md-offset-4 padding-top-20">
            <button type="submit" class="btn btn-primary" id="id-create-account-btn">Kirim</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include_once 'layouts/footer.php'; ?>
