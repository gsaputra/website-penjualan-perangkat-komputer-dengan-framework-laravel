<?php
  session_start();
  include_once 'config/koneksi.php';

  $id_barang = $_POST['id_barang'];
  $jumlah = $_POST['jumlah'];
  $queryBarang =  mysqli_query($conn, "SELECT * FROM BARANG WHERE id_barang = " . $id_barang);


    while($rowBarang = mysqli_fetch_assoc($queryBarang)){
      $grand_total = $jumlah * $rowBarang['harga'];
    }

    $queryTransaksi = mysqli_query($conn, "INSERT INTO `transaksi` (`id_pembeli`, `id_barang`, `tgl_transaksi`, `jumlah`, `grand_total`, `status`) VALUES ('". $_SESSION['id_pembeli'] ."', '". $id_barang ."', '". date('Y-m-d') ."', '".$jumlah."', '".$grand_total."', 'Belum Dibayar')");

    if($queryTransaksi){
      header('Location: sukses_beli.php');
    }else{
      echo "error";
    }
?>
