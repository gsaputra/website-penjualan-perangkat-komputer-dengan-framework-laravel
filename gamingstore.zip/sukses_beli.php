<?php include_once 'layouts/header.php';
// if(!isset($_SESSION['barang'])){
//   header('Location: index.php');
// }
?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="alert alert-success">
        <strong>Success!</strong> Barang terbeli, silahkan lanjutkan pembayaran.
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <h1>Cara Pembayaran</h1>
      <ul>
        <li>Lihat halaman history transaksi</li>
        <li>Lihat total harga yg harus dibayarkan</li>
        <li>Silahkan lanjutkan pembayaran ke no rekening BRI 156762538987635</li>
        <li>Harap cantumkan ID Transaksi dan Username akun anda di dalam detail pembayaran lalu konfirmasikan ke admin melalui Whatssap 081382885858</li>
        <li>Kirimkan bukti transfer dan alamat pengiriman ke Whatssap admin 081382885858</li>
        <li>Lihat halaman history transaksi untuk melihat perubahan status pembayaran</li>
        <li>Pengiriman dilakukan setelah melakukan pembayaran dan hanya menggunakan jasa ekspedisi TIKI-TAKA</li>
      </ul>
    </div>
  </div>
</div>

<?php include_once 'layouts/footer.php'; ?>
