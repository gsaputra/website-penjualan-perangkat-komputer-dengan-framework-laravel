<?php
  session_start();
  include_once 'config/koneksi.php';

  $username = $_POST['username'];
  $password = md5($_POST['password']);

  $login = mysqli_query($conn, "SELECT * FROM pembeli WHERE username = '" . $username . "' AND password = '" . $password . "'");
  $result = mysqli_num_rows($login);

  if($result > 0){
    $pembeli = mysqli_fetch_array($login);
    $_SESSION['id_pembeli'] = $pembeli['id_pembeli'];
    $_SESSION['nama_pembeli'] = $pembeli['nama'];
    mysqli_close($conn);
    header('Location: index.php');
   } else {
    header('Location: index.php');
  }

?>
