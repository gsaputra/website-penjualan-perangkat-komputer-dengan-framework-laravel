<?php include_once 'layouts/header.php'; ?>

<div class="container">
  <?php
    $i = 0;
    $jumlahData = 3;

    $query = "SELECT * FROM barang WHERE id_kategori = 3 ORDER BY id_barang DESC";
    $barangs = mysqli_query($conn, $query);
    $count = mysqli_num_rows($barangs);

    if ($count > 0) {
      while ($barang = mysqli_fetch_assoc($barangs)) {
        if ($i++ % $jumlahData == 0) {
          echo "<div class='row'>";
        }

      ?>
        <div class="col-lg-4">
          <img class="img-circle" src="storage/<?= $barang['gambar']; ?>" alt="Generic placeholder image" width="140" height="140">
          <h2><?= $barang['nama_barang']; ?></h2>
          <p><a class="btn btn-default" href="single.php?id=<?= $barang['id_barang']; ?>" role="button">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <?php if ($i % $jumlahData == 0 || $i == $count) {
            echo "</div>";
        } }?>
    <?php } else { ?>
      <div class="row">
        <div class="col-lg-12">
          <h2 class="text-center text-danger">Tidak ada barang di database!</h2>
        </div>
      </div>
    <?php  } ?>

</div><!-- /.container -->

<?php include_once 'layouts/footer.php'; ?>


<?php include_once 'layouts/footer.php'; ?>
