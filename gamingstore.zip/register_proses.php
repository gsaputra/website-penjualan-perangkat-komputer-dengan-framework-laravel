<?php
  include_once 'config/koneksi.php';

  $nama = $_POST['nama'];
  $telp = $_POST['telp'];
  $alamat = $_POST['alamat'];
  $username = $_POST['username'];
  $password = md5($_POST['password']);

  $query = "INSERT INTO pembeli (nama, telp, alamat, username, password) VALUES ('".$nama."', '".$telp."', '".$alamat."', '".$username."', '".$password."')";

  $result = mysqli_query($conn, $query);

  if($result){
    header('Location: index.php');
    mysqli_close($conn);
  }else{
    header('Location: index.php');
  }
?>
