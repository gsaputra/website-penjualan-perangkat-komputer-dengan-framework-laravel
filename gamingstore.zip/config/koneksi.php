<?php
    $host = "localhost";
    $username = "id10434898_defcon";
    $password = "qwerty123";
    $db = "id10434898_gamingstore";

    $conn = mysqli_connect($host, $username, $password, $db);

    if(!$conn) {
      die('Koneksi bermasalah!');
    }
?>
