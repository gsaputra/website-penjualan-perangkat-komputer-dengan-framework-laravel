<?php include_once 'layouts/header.php';
  $id_barang = $_GET['id'];

  $query = "SELECT * FROM barang WHERE id_barang = " . $id_barang;

  $result = mysqli_query($conn, $query);
  while ($row = mysqli_fetch_assoc($result)) {
 ?>
<div class="main margin-bottom-5">
      <div class="container">
        <div class="row margin-bottom-20">
          <div class="col-xs-12 margin-bottom-20 visible-xs">
            <img src="storage<?= $row['gambar']; ?>" class="img-responsive" alt=""> <!-- img thumb -->
          </div>
          <div class="col-md-3 col-sm-4 margin-bottom-20 hidden-xs">
            <a data-rel="fancybox-button" title="" href="storage/<?= $row['gambar']; ?>" class="fancybox-button">
              <img src="storage/<?= $row['gambar']; ?>" class="img-responsive" data-bigimgsrc="storage/<?= $row['gambar']; ?>" alt="">
            </a> <!-- img poster -->
  			  </div>
          <div class="col-md-9 detailEvent">
            <h1><?= $row['nama_barang']; ?></h1>
            <div>
              <table class="table table-borderless table-hover" >
                <tbody>
                  <tr>
                    <td>Stok</td>
                    <td> : </td>
                    <td>
                      <?= $row['stok']; ?>
                    </td>
                  </tr>
                  <tr>
                    <td>Harga</td>
                    <td> : </td>
                    <td>
                      Rp. <?= $row['harga']; ?>
                    </td>
                  </tr>
                  <tr>
                    <td>Kategori</td>
                    <td> : </td>
                    <td>
                      <?php
                        $querykategori = "SELECT * FROM kategori WHERE id_kategori = " . $row['id_kategori'];
                        $kategori = mysqli_query($conn, $querykategori);

                        while ($data = mysqli_fetch_assoc($kategori)) {
                          echo $data['nama_kategori'];
                        }
                      ?>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <hr>
          </div>
        </div>
      </div>
    </div>
    <div class="main margin-bottom-5" style="margin-top: 50px">
      <div class="container">
        <div class="row">
          <div class="col-md-12 tab-style-1">
            <ul class="nav nav-tabs" role="tablist">
              <li class="active">
                <a href="#quantity" data-toggle="tab" aria-controls="quantity" role="tab" aria-expanded="true">Quantity</a>
              </li>
              <li>
                <a href="#deskripsi" data-toggle="tab" aria-controls="deskripsi" role="tab" aria-expanded="false" >Description</a>
              </li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane fade in active" id="quantity">
                <div class="row voffset3">
                  <div class="col-md-12" style="margin-top: 20px">
                    <div class="form-group">
                      <div class="contact-wa">
                        <h4>Hubungi Admin untuk ketersediaan stok !</h4>
                        <h4><i class="fa fa-whatsapp fa-2x" aria-hidden="true"></i> 085892564434</h4>
                      </div>
                      <?php if(isset($_SESSION['id_pembeli'])) { ?>
                      <label for="inputJumlah" class="col-sm-2 control-label">Jumlah Beli</label>
                        <div class="col-sm-10">

                            <form action="transaksi_proses.php" method="post">
                              <input type="hidden" name="id_barang" value="<?= $row['id_barang']; ?>">
                              <input type="number" class="form-control" name="jumlah" id="jumlah" min="1" aria-describedby="helpBlocJumlah" >
                              <div class="col-sm-4 pull-right" style="margin-top: 30px">
                                <button type="submit" class="demo-loading-btn btn-lg btn btn-block btn-success add-to-cart"><span id="id-tkt-buy-btn-lbl">Beli</span></button>
                              </div>
                            </form>

                        </div>
                      <?php } ?>
                    </div>
                  </div>
                </div>
              </div>
              <div role="tabpanel" class="tab-pane" id="deskripsi">
                <div class="row voffset3">
                  <div class="col-md-12">
                    <div class="form-group">
                      <p>
                        <?= $row['deskripsi']; ?>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php } ?>
    <div class="main margin-bottom-20">
      <div class="container">
        <div class="row" id="id-b-ticket-btn-pane">
          <div class="col-md-3 text-right pull-right padding-top-15">
            <?php if(!isset($_SESSION['id_pembeli'])) { ?>
              <a class="demo-loading-btn btn-lg btn btn-block btn-success add-to-cart" data-toggle="modal" href="#bs-example-modal-sm" data-target="#bs-example-modal-sm"><span id="id-tkt-buy-btn-lbl">Harap Login untuk Beli</span></a>
          <?php } ?>
          </div>
        </div>
      </div>
    </div>
<?php include_once 'layouts/footer.php'; ?>
