<?php include_once 'layouts/header.php'; ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h1 class="page-header"> Tentang </h1>
      <p>Gaming store merupakan sebuah website penyedia perlengkapan game dan hardware komputer terbaik dikampung dukuh.</p>
    </div>
  </div>
</div>
<?php include_once 'layouts/footer.php'; ?>
